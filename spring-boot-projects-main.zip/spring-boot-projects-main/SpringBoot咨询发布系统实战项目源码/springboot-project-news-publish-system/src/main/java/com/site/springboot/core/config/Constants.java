package com.site.springboot.core.config;

/**
 * @author 13
 * @qq交流群 784785001
 * @email 2449207463@qq.com
 * @link http://13blog.site
 */
public class Constants {

    public final static String FILE_UPLOAD_PATH = "/home/project/upload/";//上传文件的保存地址，根据部署设置自行修改

}
