package cn.lanqiao.springboot3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;

@SpringBootTest
public class ApplicationTests {

    @Test
    public void test() throws SQLException {

    }
}
