function test() {
    console.log('resource - js');
}