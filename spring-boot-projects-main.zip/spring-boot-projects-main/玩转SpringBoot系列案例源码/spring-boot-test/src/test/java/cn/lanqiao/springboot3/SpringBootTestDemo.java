package cn.lanqiao.springboot3;

import org.junit.jupiter.api.Test;

public class SpringBootTestDemo {
    @Test
    public void test1(){
        System.out.println("test1");
    }
}
